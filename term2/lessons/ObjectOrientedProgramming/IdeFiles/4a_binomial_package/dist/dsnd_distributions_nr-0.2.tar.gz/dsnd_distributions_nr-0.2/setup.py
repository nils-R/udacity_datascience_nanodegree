from setuptools import setup

setup(name='dsnd_distributions_nr',
      version='0.2',
      description='Gaussian and binomial distributions',
      author='Nils Randau',
      packages=['dsnd_distributions_nr'],
      zip_safe=False)
